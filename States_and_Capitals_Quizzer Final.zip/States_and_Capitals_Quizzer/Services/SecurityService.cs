﻿using States_and_Capitals_Quizzer.Models;

namespace States_and_Capitals_Quizzer.Services
{
    public class SecurityService
    {

        // Check user
        UsersDAO usersDAO = new UsersDAO();    
        public bool IsValid(UserModel user, string connectionStr)
        {
            return usersDAO.FindIfUserExists(user, connectionStr);
        }

        // Get userId
        userIdDAO userIdDAO = new userIdDAO();
        public int GetUserID(UserModel user, string connectionStr)
        {
            return userIdDAO.FindUserID(user, connectionStr);
        }

        // Get states and capitals
        QuizDAO quizDAO = new QuizDAO();
        public List<QuizModel> GetQuizValues(QuestionNumberModel qNumber, string connectionStr)
        {
            return quizDAO.FindQuestionsAndAnswers(qNumber, connectionStr);
        }

        // Used to save results from quiz
        GradingDAO GradingDAO = new GradingDAO();
        public bool SendResults(QuizGradingModel results, string connectionStr)
        {
            return GradingDAO.SaveResults(results, connectionStr);
        }


    }
}
