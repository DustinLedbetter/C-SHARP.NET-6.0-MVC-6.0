﻿using States_and_Capitals_Quizzer.Models;
using System.Data.SqlClient;

namespace States_and_Capitals_Quizzer.Services
{
    public class QuizDAO
    {
        // Used to get all of the question data: (States and Capitals)
        public List<QuizModel> FindQuestionsAndAnswers(QuestionNumberModel qNumber, string connStr)
        {

            string connectionString = connStr;

            // Comment to team that User is a keyword and can't be a table name!  
            string sqlFindQAndAQuery = "SELECT * FROM dbo.State StatesAll JOIN (SELECT TOP " + qNumber.QuestionNumber + "StateId FROM dbo.State order by newid()) AS StatesRand ON StatesAll.StateId=StatesRand.StateId;";

            var questionsAndAnswers = new List<QuizModel>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand findQAndA = new SqlCommand(sqlFindQAndAQuery, connection);

                try
                {
                    connection.Open();
                    using (SqlDataReader reader = findQAndA.ExecuteReader())

                        if (reader.HasRows)
                        {
                            // deal with values and pass to questions
                            while (reader.Read())
                            {
                                string? stateId = reader["StateId"].ToString();
                                string? state = reader["State"].ToString();
                                string? capital = reader["Capital"].ToString();

                                //Console.WriteLine("State ID: " + stateId + " State: " + state + " Capital: " + capital);

                                questionsAndAnswers.Add(new QuizModel()
                                {
                                    StateId = (int)reader["StateId"],
                                    State = (string)reader["State"],
                                    Capital = (string)reader["Capital"]
                                });

                            }

                        }

                    connection.Close();

                }
                catch (Exception e)
                {
                    // Log values to actual log, but for test just console
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Caught in catch Quiz");
                }

                return questionsAndAnswers;

            }

        }


    }
}
