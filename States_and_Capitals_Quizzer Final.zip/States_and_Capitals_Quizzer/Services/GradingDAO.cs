﻿using States_and_Capitals_Quizzer.Models;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace States_and_Capitals_Quizzer.Services
{
    public class GradingDAO
    {

        // Used to save the results of the quiz to the DB
        public bool SaveResults(QuizGradingModel save, string connStr)
        {
            string connectionString = connStr;
            bool successfulConnection = false;

            // Comment to team that User is a keyword and can't be a table name!  
            string sqlSaveQuery = "INSERT INTO dbo.TestResult(UserId, TestDateTime, TotalQuestions, NumberCorrect) VALUES (" + save.UserId + ", GETDATE (), " + save.QuestionCount + ", " + save.NumberCorrect + ");";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand saveResults = new SqlCommand(sqlSaveQuery, connection);

                try
                {
                    connection.Open();
                    int trySave = saveResults.ExecuteNonQuery();
                    connection.Close();

                    if (trySave == -1)
                    {
                        successfulConnection = true;
                    }
                    
                }
                catch (Exception e)
                {
                    // Log values to actual log, but for test just console
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Caught in catch results");
                }

                return successfulConnection;

            }

        }


    }
}
