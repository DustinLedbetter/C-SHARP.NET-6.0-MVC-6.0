﻿using States_and_Capitals_Quizzer.Models;
using System.Data.SqlClient;

namespace States_and_Capitals_Quizzer.Services
{
    public class userIdDAO
    {
        // Used to get the userId for those who had valid credentials
        public int FindUserID(UserModel user, string connStr)
        {
            string connectionString = connStr;

            string sqlFindUserIdQuery = "SELECT * FROM dbo.Users WHERE UserName = @username AND Password = @password";
            int userID = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand findUserID = new SqlCommand(sqlFindUserIdQuery, connection);

                findUserID.Parameters.Add("@username", System.Data.SqlDbType.NVarChar, 255).Value = user.UserName;
                findUserID.Parameters.Add("@password", System.Data.SqlDbType.NVarChar, 255).Value = user.Password;

                try
                {
                    connection.Open();
                    SqlDataReader reader = findUserID.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            userID = (int)reader["UserId"];
                            Console.WriteLine(userID);
                        }
                    }

                }
                catch (Exception e)
                {
                    // Log values to actual log, but for test just console
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Caught in catch userId");
                }

                connection.Close();

                return userID;

            }

        }
      

    }

}
