﻿using States_and_Capitals_Quizzer.Models;
using System.Data.SqlClient;

namespace States_and_Capitals_Quizzer.Services
{
    public class UsersDAO
    {
        // Used to find if we have valid user credentials
        public bool FindIfUserExists(UserModel user, string connStr)
        {

            string connectionString = connStr;

            //comment to team that User is a keyword and can't be a table name!  
            string sqlFindIfValidUserQuery = "SELECT * FROM dbo.Users WHERE UserName = @username AND Password = @password";
            bool successfulConnection = false;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand findIfValidUser = new SqlCommand(sqlFindIfValidUserQuery, connection);
             
                findIfValidUser.Parameters.Add("@username", System.Data.SqlDbType.NVarChar, 255).Value = user.UserName;
                findIfValidUser.Parameters.Add("@password", System.Data.SqlDbType.NVarChar, 255).Value = user.Password;

                try
                {
                    connection.Open();
                    SqlDataReader reader = findIfValidUser.ExecuteReader();

                    if (reader.HasRows)
                    {
                        successfulConnection = true;
                    }

                }
                catch(Exception e)
                {
                    // Log values to actual log, but for test just console
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Caught in catch user");
                }

                connection.Close();

                return successfulConnection;

            }

        }

    
    }
}
