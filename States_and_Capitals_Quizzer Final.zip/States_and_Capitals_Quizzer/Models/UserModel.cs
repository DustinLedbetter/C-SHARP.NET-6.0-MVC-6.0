﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace States_and_Capitals_Quizzer.Models
{
    public class UserModel
    {
        [Required]
        [DisplayName("Username must be provided!")]
        public string? UserName { get; set; }

        [Required]
        [DisplayName("Password must be provided!")]
        public string? Password { get; set; }

    }


}
