﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace States_and_Capitals_Quizzer.Models
{
    public class QuestionNumberModel
    {

        [Required]
        [DisplayName("Number must be provided!")]
        [Range(10,50)]
        public int QuestionNumber { get; set; }

    }
}
