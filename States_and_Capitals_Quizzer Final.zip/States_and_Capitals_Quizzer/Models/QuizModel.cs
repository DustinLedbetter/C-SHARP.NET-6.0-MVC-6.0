﻿namespace States_and_Capitals_Quizzer.Models
{
    public class QuizModel
    {
        public int? StateId { get; set; }
        public string? State { get; set; }
        public string? Capital { get; set; }

    }


}
