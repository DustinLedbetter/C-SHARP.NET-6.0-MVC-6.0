﻿namespace States_and_Capitals_Quizzer.Models
{

    public class QuizGradingModel
    {
        public int? UserId { get; set; }
        public int? QuestionCount { get; set; }
        public int? NumberCorrect { get; set; }

    }


}
