﻿using Microsoft.AspNetCore.Mvc;
using States_and_Capitals_Quizzer.Models;
using States_and_Capitals_Quizzer.Services;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.Extensions.Configuration;

namespace States_and_Capitals_Quizzer.Controllers
{
    public class LoginController : Controller
    {

        // Variables
        static int counter = 0;
        static object lockObj = new object();

        // Go to Login page (Where user enters their username and password)
        public IActionResult LoginIndex()
        {
            ViewBag.Header = "LoginPage";
            return View();

        }

        // Call Process Login which will take user provided credentials and test to make sure they are vaild. If they are, we take them to home page
        public IActionResult ProcessLogin(UserModel userModel)
        {
            // Get our connection string from appsettings.json and call secure service to keep data safer
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: false);
            IConfiguration config = builder.Build();
            string connectionString = config.GetValue<string>("ConnectionStrings:appDbConnection");

            ViewBag.Header = "LoginPage";

            SecurityService securityService = new SecurityService();

            // Check if the credentials are valid
            if (securityService.IsValid(userModel, connectionString))
            {
                // If valid, but they failed the login more than 3 times, we still prevent access
                if (counter >= 2)
                {
                    return View("FailLogin");
                }
                // We are valid and can move forward
                else
                {
                    // Get userID to pass through pages and for storing results to DB
                    var userID = securityService.GetUserID(userModel,connectionString);
                    TempData["UserID"] = userID;

                    // Since we are a valid user, we can move to home page now
                    return RedirectToAction("HomeIndex", "Home", userModel);
                }
            }
            // If invalid credentials, we check if three times or more which will lock them out
            else
            {
                // If invalid and they failed the login more than 3 times we prevent access
                if (counter >= 2)
                {
                    return View("FailLogin");
                }
                // Allow them to try to enter credentials again
                else
                {
                    lock (lockObj)
                    {
                        counter++;
                    }

                    //Console.WriteLine(counter);
                    //Console.WriteLine(lockObj);
                    //Console.WriteLine("You failed login attempts");

                    return View("LoginIndex");
                }
            }

        }


    }
}
