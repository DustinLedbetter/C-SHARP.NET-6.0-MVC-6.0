﻿using Microsoft.AspNetCore.Mvc;
using States_and_Capitals_Quizzer.Models;
using States_and_Capitals_Quizzer.Services;
using System.Data;
using System.Diagnostics;
using System.Dynamic;
using Microsoft.Extensions.Configuration;

namespace States_and_Capitals_Quizzer.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;

        }

        // Go to Home page (Where user enters number of questions)
        public IActionResult HomeIndex()
        {
            return View();

        }

        // Go to About page to learn about project
        public IActionResult About()
        {
            return View();

        }

        // Go to Privacy page to be told not to steal or use with permission
        public IActionResult Privacy()
        {
            return View();

        }

        // Go to Quiz Start page (The form that has all the questions and user tries to answer them correctly)
        public IActionResult ProcessQuizStart(QuestionNumberModel qNumber)
        {

            // Make sure the question count is in proper range and provided
            if (ModelState.IsValid)
            {
                // Get our connection string from appsettings.json and call secure service to keep data safer
                var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: false);
                IConfiguration config = builder.Build();
                string connectionString = config.GetValue<string>("ConnectionStrings:appDbConnection");

                SecurityService securityService = new SecurityService();

                var QuestionsAndAnswers = securityService.GetQuizValues(qNumber, connectionString);

                // Store all questions and answers into ViewBag for looping through on view
                ViewBag.QuestionsAndAnswers = QuestionsAndAnswers;
                return View();
            }
            else
            {
                // Make user provide a proper question count
                return View("HomeIndex");
            }
  
        }

        // Use to send quiz results to the DB and then after giving user time to review their answers. We then return back to home screen where they can retake test again
        [HttpPost]
        public ActionResult PostExam(QuizGradingModel resultQuiz)
        {
            // Get our connection string from appsettings.json and call secure service to keep data safer 
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: false);
            IConfiguration config = builder.Build();
            string connectionString = config.GetValue<string>("ConnectionStrings:appDbConnection");

            SecurityService securityService = new SecurityService();

            // We would normally want to check if data saved successfully and log it as well as alert user of a failure to save to DB possibly, but I don't want to alarm user that their is an issue in this instance
            if (securityService.SendResults(resultQuiz, connectionString))
            {
                // Log of success
            }
            else
            {
                // Log of failure
            }

            // Give the user 1 min to review their questions and answers
            Thread.Sleep(60000);

            // Return back to home screen where they can retake test again
            return View("HomeIndex");

        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });

        }


    }
}